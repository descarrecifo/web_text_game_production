package com.company;
import static com.company.view.IOView.MainLoopView;

public class Main {

    public static void main(String[] args) {

        //we are starting the main loop
        MainLoopView();

        //Exit program
        System.out.println("\nExperamos verte pronto, aventurero!");
    }
}
