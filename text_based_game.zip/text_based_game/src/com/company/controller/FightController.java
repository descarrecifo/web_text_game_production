package com.company.controller;

public class FightController {
    int level;
}
