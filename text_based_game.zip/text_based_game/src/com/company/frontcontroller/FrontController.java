package com.company.frontcontroller;

public class FrontController {
}
