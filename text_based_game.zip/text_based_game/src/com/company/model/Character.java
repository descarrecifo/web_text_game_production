package com.company.model;

public class Character {
}
