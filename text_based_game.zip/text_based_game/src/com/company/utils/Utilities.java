package com.company.utils;
import java.util.Scanner;

public class Utilities {
    public static String ask(Scanner scanner, String text) {    //this method receives the scanner and a String,
        System.out.println(text);                               //and returns the output of the scanner inserted by the user
        return scanner.next();
    }
}
