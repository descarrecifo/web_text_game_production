package com.company.view;

import org.w3c.dom.ls.LSOutput;
import com.company.utils.Utilities.*;

import java.util.Scanner;


public class IOView {

    public static void MainLoopView() {
        Scanner reader = new Scanner(System.in);

        while (true) {

            MainMenu();
            String optionMenuMain = reader.nextLine();
            switch (optionMenuMain) {

                case "1" -> {
                    MenuNewGame();
                    OptionsMenuNewGame();
                }

                case "2" -> System.out.println("Opcion 2");
                default -> {
                    System.out.println("Opcion invalida \n");
                }
            }
        }
    }

    public static void MainMenu() {
        System.out.println("****************************************************");
        System.out.println("1- Nueva partida");
        //System.out.println("****************************************************");
        System.out.println("2- Salir");
        System.out.println("****************************************************");
    }

    public static void MenuNewGame() {
        System.out.println("****************************************************");
        System.out.println("1- Lucha");
        System.out.println("2- Inventario");
        //System.out.println("****************************************************");
        System.out.println("3- Salir");
        System.out.println("****************************************************");
    }

    public static void OptionsMenuNewGame() {
        Scanner reader = new Scanner(System.in);

        String keyMenuNewGame = reader.nextLine();

        //if (keyMenuNewGame.equals("1") || keyMenuNewGame.equals("2")) {
        // while(true){
        switch (keyMenuNewGame) {

            case "1" -> {
                System.out.println("Opciones Lucha");
                System.out.println("OK. Volvemos a Menu principal");
                return;
            }

            case "2" -> {
                System.out.println("Opciones Inventario");
                System.out.println("OK. Volvemos a Menu principal");
                return;
            }
            case "3" -> {
                System.out.println("Volvemos al menu principal");
                break;

            }
            default -> {
                System.out.println("Opcion invalida Menu Juego. Reinténtalo");
            }

        }

        //}
    }
}


